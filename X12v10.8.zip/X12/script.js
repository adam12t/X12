const tabBtn = document.querySelectorAll(".tabs");
const tabItem = document.querySelectorAll(".tab");

tabBtn.forEach(function(item) {
    item.addEventListener("click", function(){
        let currentBtn = item;
        let tabId = currentBtn.getAttribute("data-tab");
        let currentTab = document.querySelector(tabId)

        tabBtn.forEach(function(item) {
            item.classList.remove("active");

        });

        tabItem.forEach(function(item) {
            item.classList.remove("active");

        });

        currentBtn.classList.add("active");
        currentTab.classList.add("active")
    })

})